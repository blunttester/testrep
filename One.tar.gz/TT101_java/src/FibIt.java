import java.io.*;

public class FibIt {
    
    public static void Iterative () throws Exception {
        try{
           int result=0;
            //Reading the inp
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("#######################################");
            System.out.println("\nWhich Fibonacci -number you want to get?");
            String number = input.readLine();
            int n=Integer.parseInt(number);
            System.out.println("You gave\t"+n);
         if (n<2) {
            result=n;
            
            }
        else {
            int a=0,b=1,sum=0;
            for (int i=0;i<n;i++) {
                sum = a+b;
                a=b;
                b=sum;
            
                }
            result = a;
           }
         BufferedReader in = new BufferedReader(new FileReader("report.txt")); 
         String report="";   
         while (in.ready()) { 
            report = in.readLine(); 
            //System.out.println(report); 
            }
            try (PrintWriter out = new PrintWriter(new FileWriter("report.txt"))) {
                //out.print(report);
                out.println(report+"::Fibonacci Iterative ("+n+") :"+result);
            }

            System.out.println("Fibonacci ("+n+") :"+result);
            System.out.println("\n\tPRESS ENTER TO RETURN");
            System.out.println("#######################################");
             BufferedReader wait = new BufferedReader(new InputStreamReader(System.in));
            wait.readLine();
            
        } catch (IOException ioe){
            System.out.println(ioe.toString());
            
        }
        
        
        
    }
}