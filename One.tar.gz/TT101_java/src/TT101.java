
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class TT101 {

    public static void main(String[] args) throws Exception {
        try {
            boolean n=true;
            while (n){
                StringBuilder sInput= new StringBuilder();;
            //Reading the input
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("#######################################");            
            System.out.println("Select the desired action:\n0: Fibonacci Iterative\n1: Fibonacci recursive");
            System.out.println("2: Palindrome\n3: Randomizer");
            System.out.println("4: INFO\n5: Test Report\n6: EXIT");
            String number = input.readLine();
            int choice=Integer.parseInt(number);
            
            
                
                switch (choice){
                
                    case 0: FibIt.Iterative();
                            n=true;
                            break;
                    case 1:  FibRec.Recursive();
                            n=true;
                            break;
                    case 2: Palindromi.Check();
                            n=true;
                            break;
                    case 3: Rndmzr.Rndm();
                            n=true;
                            break;
                    case 4: Information.PrintInfo();
                            n=true;
                            break;
                   case 5: Information.PrintResults();
                            n=true;
                            break;
                    case 6: n=false;
                            break;
                    }
            
        }
          System.out.println("So Long, and Thanks for All the Fish!");
          System.out.println("\n#######################################");
    }
catch(Exception e)
		{
                    
			System.out.println("OOPS!! "+e);
		}

    }
}
