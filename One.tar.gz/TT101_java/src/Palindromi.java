/**
 * Palindromi.java
 * A java -program which checks wether the entered string
 * is A Palindrome or not
 * @author Jan Matilainen
 */
import java.io.*;
public class Palindromi {

    public static void Check() throws Exception {
        try{
           //Reading the input
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("#######################################");             
            System.out.println("Give the string to be checked.\nNOTE:Program is NOT case -sensitive");
            String s1=input.readLine().toLowerCase().replaceAll(" ", "");
            System.out.println("You gave\t"+s1);
            //Getting the entered string backwards
            StringBuilder s2 = new StringBuilder();
            int length =s1.length();
            for (int i= length;i>0;--i){
                char temp = s1.charAt(i-1);
                s2.append(temp);
                //System.out.println(s2);
            }
            s2.toString();
           //Checking the results
            String result="";
            if (s1.equals(s2.toString())){
                result=s1+" is a palindrome.";
            }
            else{
                result=s1+" is NOT a palindrome.";
            }
            BufferedReader in = new BufferedReader(new FileReader("report.txt")); 
            String report="";   
            while (in.ready()) { 
                    report = in.readLine(); 
                    
            //System.out.println(report); 
                }
            try (PrintWriter out = new PrintWriter(new FileWriter("report.txt"))) {
                //out.print(report);
                out.println(report+"::Palindrome Check:"+result);
            }catch (IOException ioe){
            System.out.println(ioe.toString());
            }
            
            System.out.println("You gave\t\t"+s1);
            System.out.println("Which is backwards\t"+s2);
            System.out.println(result);
            System.out.println("\n\tPRESS ENTER TO RETURN");
            System.out.println("#######################################");
             BufferedReader wait = new BufferedReader(new InputStreamReader(System.in));
            wait.readLine();
        } catch (IOException ioe){
            System.out.println(ioe.toString());
        }
        
        
        
    }
}
