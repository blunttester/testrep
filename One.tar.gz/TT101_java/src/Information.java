
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author SumppiWee
 */
public class Information {
     public static void PrintInfo () throws Exception {
        try{
             BufferedReader fInfo  = new BufferedReader(new FileReader("README.TXT"));
                    
                    System.out.println("#######################################\n");
                    while (fInfo.ready()) { 
                        String sTxt = fInfo.readLine();
                      System.out.println(sTxt); 
                                            }
                    System.out.println("\n\tPRESS ENTER TO RETURN");
                    System.out.println("#######################################");
             BufferedReader wait = new BufferedReader(new InputStreamReader(System.in));
            wait.readLine();
        }catch (IOException ioe){
            System.out.println(ioe.toString());
        }
        

}
          public static void PrintResults () throws Exception {
        try{
             BufferedReader fInfo  = new BufferedReader(new FileReader("report.txt"));
                    
                    System.out.println("#######################################\n");
                    while (fInfo.ready()) { 
                        String sTxt = fInfo.readLine();
                      System.out.println(sTxt); 
                                            }
                    System.out.println("\n\tPRESS ENTER TO RETURN");
                    System.out.println("#######################################");
             BufferedReader wait = new BufferedReader(new InputStreamReader(System.in));
            wait.readLine();
        }catch (IOException ioe){
            System.out.println(ioe.toString());
        }   
}
}
