
import java.io.*;
import java.util.*;

public class Rndmzr {
     public static void Rndm() throws Exception{
        try{
            StringBuilder sRndm= new StringBuilder();;
            //Reading the input
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("#######################################");
             System.out.println("\nHow many characters should the randomized number be?");
            String number = input.readLine();
            int n=Integer.parseInt(number);
            System.out.println("You gave\t"+n);
            
           for (int i=0;i<n;i++){
               long a=System.currentTimeMillis();
               long b=System.nanoTime();
               sRndm.append((int) ((b%a)%n));
           }
           String result = sRndm.toString();
                   BufferedReader in = new BufferedReader(new FileReader("report.txt")); 
                 String report="";   
                 while (in.ready()) { 
                    report = in.readLine(); 
            //System.out.println(report); 
                            }
                try (PrintWriter out = new PrintWriter(new FileWriter("report.txt"))) {
                                //out.print(report);
                                out.println(report+"::Randomized number: "+result);
            }catch (IOException ioe){
            System.out.println(ioe.toString());
            }
         System.out.println("Randomized number: "+result);
         System.out.println("\n\tPRESS ENTER TO RETURN");
            System.out.println("#######################################");
             BufferedReader wait = new BufferedReader(new InputStreamReader(System.in));
            wait.readLine();
        } catch (IOException ioe){
            System.out.println(ioe.toString());
            
        }
        
        
        
    }
}
