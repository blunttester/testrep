
import java.io.*;


public class FibRec {
    
    public static void Recursive() throws Exception{
        try{
           int result=0;
            //Reading the input
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("#######################################");             
            System.out.println("\nWhich Fibonacci -number you want to get?");
            String number = input.readLine();
            int n=Integer.parseInt(number);
            System.out.println("You gave\t"+n);

            result=fibonacciRecursive(n);
                  BufferedReader in = new BufferedReader(new FileReader("report.txt")); 
         String report="";   
         while (in.ready()) { 
            report = in.readLine(); 
            //System.out.println(report); 
            }
            try (PrintWriter out = new PrintWriter(new FileWriter("report.txt"))) {
                //out.print(report);
                out.println(report+"::Fibonacci Recursive ("+n+") :"+result);
            }catch (IOException ioe){
            System.out.println(ioe.toString());
        }
            System.out.println("Fibonacci Recursive ("+n+") :"+result);
            System.out.println("\n\tPRESS ENTER TO RETURN");
            System.out.println("#######################################");
             BufferedReader wait = new BufferedReader(new InputStreamReader(System.in));
            wait.readLine();
        } catch (IOException ioe){
            System.out.println(ioe.toString());
        }
        
        
        
    }
    public static int fibonacciRecursive(int n) {
            if (n<2) {
             return n;
            }
            else{
            return fibonacciRecursive(n-1) + fibonacciRecursive(n-2);
            }

        }
}